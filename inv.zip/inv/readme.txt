-See the spice log files for measurement results. 

-Both circuits are clocked.

-Outputs will be ready after falling edge of the clock.

Static Power Measurements

./ltspice/inv_tlg/inv_tlg_static_power.asc <- TLG + STD

./ltspice/inv_std_ff/inv_std_ff_static_power.asc <- STD + FF

Power and Delay Measurements

./ltspice/inv_tlg/inv_tlg_power_delay.asc <- TLG + STD

./ltspice/inv_std_ff/inv_std_ff_power_delay.asc <- STD + FF

