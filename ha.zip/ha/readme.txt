-See the spice log files for measurement results. 

-Both circuits are clocked.

-Outputs will be ready after falling edge of the clock.

Static Power Measurements

./ltspice/ha_tlg/ha_tlg_static_power.asc <- TLG + STD

./ltspice/ha_std/ha_std_static_power.asc <- STD

./ltspice/ha_std_ff/ha_std_ff_static_power.asc <- STD + FF

Power and Delay Measurements

./ltspice/ha_tlg/ha_tlg_power_delay.asc <- TLG + STD

./ltspice/ha_std/ha_std_power_delay.asc <- STD

./ltspice/ha_std_ff/ha_std_ff_power_delay.asc <- STD + FF