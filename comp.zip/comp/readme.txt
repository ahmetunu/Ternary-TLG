-See the spice log files for measurement results. 

-Both circuits are clocked.

-Outputs will be ready after falling edge of the clock.

Static Power Measurements

./ltspice/comp_tlg/comp_tlg_static_power.asc <- TLG + STD

./ltspice/comp_std_ff/comp_std_ff_static_power.asc <- STD + FF

Power and Delay Measurements

./ltspice/comp_tlg/comp_tlg_power_delay.asc <- TLG + STD

./ltspice/comp_std_ff/comp_std_ff_power_delay.asc <- STD + FF